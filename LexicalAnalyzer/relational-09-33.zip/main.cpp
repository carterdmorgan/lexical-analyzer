//
//  main.cpp
//  LexicalAnalyzer
//
//  Created by Morgan, Carter on 9/20/18.
//  Copyright © 2018 carterdmorgan. All rights reserved.
//

#include <iostream>
#include <string>
#include <stdio.h>
#include <ctype.h>
#include <sstream>
#include <fstream>
#include <vector>
#include <set>
#include "Lex.h"
#include "TokenType.h"
#include "DatalogProgram.h"
#include "InvalidTokenException.cpp"
#include "Scheme.h"
#include "Fact.h"
#include "Rule.h"
#include "Query.h"
#include "DLString.h"
#include "Header.h"
#include "Table.h"

using namespace std;

// Tests if select can find all tuples that have a constant in a certain column
bool test0() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("b");
    row0.values.push_back("c");
    row1.values.push_back("a");
    row1.values.push_back("e");
    row1.values.push_back("f");
    row2.values.push_back("b");
    row2.values.push_back("e");
    row2.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("0");
    desired.header.push_back("1");
    desired.header.push_back("2");
    Row row3 = Row();
    Row row4 = Row();
    row3.values.push_back("a");
    row3.values.push_back("b");
    row3.values.push_back("c");
    row4.values.push_back("a");
    row4.values.push_back("e");
    row4.values.push_back("f");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    
    Table result = table.select(0, "a");
    
    return desired == result;
}

// Tests if select can find all the tuples that have the same value in two columns
bool test1() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("c");
    row1.values.push_back("b");
    row1.values.push_back("b");
    row1.values.push_back("f");
    row2.values.push_back("b");
    row2.values.push_back("e");
    row2.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("0");
    desired.header.push_back("1");
    desired.header.push_back("2");
    Row row3 = Row();
    Row row4 = Row();
    row3.values.push_back("a");
    row3.values.push_back("a");
    row3.values.push_back("c");
    row4.values.push_back("b");
    row4.values.push_back("b");
    row4.values.push_back("f");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    
    Table result = table.select(0, 1);
    
    return desired == result;
}

// Tests if a single column can be removed while two others remain using project
bool test2() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("c");
    row1.values.push_back("b");
    row1.values.push_back("b");
    row1.values.push_back("f");
    row2.values.push_back("b");
    row2.values.push_back("e");
    row2.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("1");
    desired.header.push_back("2");
    Row row3 = Row();
    Row row4 = Row();
    Row row5 = Row();
    row3.values.push_back("a");
    row3.values.push_back("c");
    row4.values.push_back("b");
    row4.values.push_back("f");
    row5.values.push_back("e");
    row5.values.push_back("f");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    desired.rows.push_back(row5);
    
    vector<int> columns;
    columns.push_back(1);
    columns.push_back(2);
    
    Table result = table.project(columns);
    
//    table.print();
//    cout << endl;
//    desired.print();
//    cout << endl;
//    result.print();
    
    return desired == result;
}

// Tests if a single column can remain after using project
bool test3() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("c");
    row1.values.push_back("b");
    row1.values.push_back("b");
    row1.values.push_back("f");
    row2.values.push_back("b");
    row2.values.push_back("e");
    row2.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("1");
    Row row3 = Row();
    Row row4 = Row();
    Row row5 = Row();
    row3.values.push_back("a");
    row4.values.push_back("b");
    row5.values.push_back("e");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    desired.rows.push_back(row5);
    
    Table result = table.project(1);
    
    return desired == result;
}

// Tests if project can swap the first and third columns
bool test4() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("b");
    row0.values.push_back("c");
    row1.values.push_back("a");
    row1.values.push_back("e");
    row1.values.push_back("f");
    row2.values.push_back("b");
    row2.values.push_back("e");
    row2.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("2");
    desired.header.push_back("1");
    desired.header.push_back("0");
    Row row3 = Row();
    Row row4 = Row();
    Row row5 = Row();
    row3.values.push_back("c");
    row3.values.push_back("b");
    row3.values.push_back("a");
    row4.values.push_back("f");
    row4.values.push_back("e");
    row4.values.push_back("a");
    row5.values.push_back("f");
    row5.values.push_back("e");
    row5.values.push_back("b");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    desired.rows.push_back(row5);
    
    Table result = table.project(0, 2);

    return desired == result;
}

// Tests if multiple column headers can be renamed
bool test5() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    Row row0 = Row();
    Row row1 = Row();
    Row row2 = Row();
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("c");
    row1.values.push_back("b");
    row1.values.push_back("b");
    row1.values.push_back("f");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    
    Table desired = Table("test");
    desired.header.push_back("2");
    desired.header.push_back("1");
    desired.header.push_back("0");
    Row row3 = Row();
    Row row4 = Row();
    row3.values.push_back("a");
    row3.values.push_back("a");
    row3.values.push_back("c");
    row4.values.push_back("b");
    row4.values.push_back("b");
    row4.values.push_back("f");
    desired.rows.push_back(row3);
    desired.rows.push_back(row4);
    
    vector<int> values;
    vector<string> names;
    values.push_back(0);
    values.push_back(2);
    names.push_back("2");
    names.push_back("0");
    
    Table result = table.rename(values, names);

    return desired == result;
}

// Tests the query SNAP('x',Y)
bool test6() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    Row row0 = Row();
    Row row1 = Row();
    row0.values.push_back("x");
    row0.values.push_back("z");
    row1.values.push_back("a");
    row1.values.push_back("b");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    
    Table desired = Table("test");
    desired.header.push_back("Y");
    Row row2 = Row();
    row2.values.push_back("z");
    desired.rows.push_back(row2);
    
    table = table.select(0, "x");
    table = table.project(1);
    table = table.rename(0, "Y");
    
    return desired == table;
}

// Tests the query SNAP('s',X,X,Y)
bool test7() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    table.header.push_back("3");
    Row row0 = Row();
    row0.values.push_back("s");
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("d");
    Row row1 = Row();
    row1.values.push_back("a");
    row1.values.push_back("b");
    row1.values.push_back("c");
    row1.values.push_back("d");
    Row row2 = Row();
    row2.values.push_back("s");
    row2.values.push_back("z");
    row2.values.push_back("z");
    row2.values.push_back("q");
    Row row3 = Row();
    row3.values.push_back("d");
    row3.values.push_back("z");
    row3.values.push_back("z");
    row3.values.push_back("q");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    table.rows.push_back(row3);
    
    Table desired = Table("test");
    desired.header.push_back("X");
    desired.header.push_back("Y");
    Row row4 = Row();
    row4.values.push_back("a");
    row4.values.push_back("d");
    Row row6 = Row();
    row6.values.push_back("z");
    row6.values.push_back("q");
    desired.rows.push_back(row4);
    desired.rows.push_back(row6);
    
    vector<int> projections;
    projections.push_back(2);
    projections.push_back(3);
    
    vector<int> columns;
    columns.push_back(0);
    columns.push_back(1);
    
    vector<string> names;
    names.push_back("X");
    names.push_back("Y");
    
    table = table.select(0, "s");
    table = table.select(1, 2);
    table = table.project(projections);
    table = table.rename(columns, names);
    
    return table == desired;
}

// Tests the query SNAP('s',X)
bool test8() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    table.header.push_back("3");
    Row row0 = Row();
    row0.values.push_back("s");
    row0.values.push_back("a");
    row0.values.push_back("a");
    row0.values.push_back("d");
    Row row1 = Row();
    row1.values.push_back("a");
    row1.values.push_back("b");
    row1.values.push_back("c");
    row1.values.push_back("d");
    Row row2 = Row();
    row2.values.push_back("s");
    row2.values.push_back("a");
    row2.values.push_back("z");
    row2.values.push_back("q");
    Row row3 = Row();
    row3.values.push_back("d");
    row3.values.push_back("z");
    row3.values.push_back("z");
    row3.values.push_back("q");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    table.rows.push_back(row3);
    
    Table desired = Table("test");
    desired.header.push_back("X");
    Row row4 = Row();
    row4.values.push_back("a");
    Row row5 = Row();
    row5.values.push_back("a");
    desired.rows.push_back(row4);
    desired.rows.push_back(row5);
    
    table = table.select(0, "s");
    table = table.project(1);
    table = table.rename(0, "X");
    
    return table == desired;
}

// Tests query SNAP(X,X,Y,Y)
bool test9() {
    Table table = Table("test");
    table.header.push_back("0");
    table.header.push_back("1");
    table.header.push_back("2");
    table.header.push_back("3");
    Row row0 = Row();
    row0.values.push_back("s");
    row0.values.push_back("s");
    row0.values.push_back("a");
    row0.values.push_back("a");
    Row row1 = Row();
    row1.values.push_back("a");
    row1.values.push_back("a");
    row1.values.push_back("s");
    row1.values.push_back("s");
    Row row2 = Row();
    row2.values.push_back("b");
    row2.values.push_back("b");
    row2.values.push_back("z");
    row2.values.push_back("z");
    Row row3 = Row();
    row3.values.push_back("d");
    row3.values.push_back("z");
    row3.values.push_back("z");
    row3.values.push_back("q");
    table.rows.push_back(row0);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    table.rows.push_back(row3);
    
    Table desired = Table("test");
    desired.header.push_back("X");
    desired.header.push_back("Y");
    Row row4 = Row();
    row4.values.push_back("s");
    row4.values.push_back("a");
    Row row5 = Row();
    row5.values.push_back("a");
    row5.values.push_back("s");
    Row row6 = Row();
    row6.values.push_back("b");
    row6.values.push_back("z");
    desired.rows.push_back(row4);
    desired.rows.push_back(row5);
    desired.rows.push_back(row6);
    
    vector<int> projections;
    projections.push_back(1);
    projections.push_back(3);
    
    vector<int> columns;
    columns.push_back(0);
    columns.push_back(1);
    
    vector<string> names;
    names.push_back("X");
    names.push_back("Y");
    
    table = table.select(0, 1);
    table = table.select(2, 3);
    table = table.project(projections);
    table = table.rename(columns, names);
    
    return table == desired;
}



int main(int argc, const char * argv[]) {    
//    // Part 2
//    string fileName = argv[1];
//    ifstream inFile(fileName);
//    string input = "";
//    string line;
//
//    if (inFile.is_open()) {
//        while (getline(inFile,line)) {
//            input += line;
//            input += '\n';
//        }
//        inFile.close();
//    }
//
//    DatalogProgram datalogProgram = DatalogProgram();
//
//    try {
//        Lex lex = Lex(input);
//        datalogProgram.process(lex);
//        DatalogProgram::print(datalogProgram);
//    }catch (InvalidTokenException e) {
//        cout << "Failure!" << endl;
//        cout << "  (" << e.getTokenType() << ",\"" << e.getToken() << "\"," << e.getLine() << ")" << endl;
//    }
    
    if(test0()) {
        cout << "TEST 1 PASSED!" << endl;
    }else {
        cout << "TEST 1 FAILED!" << endl;
    }
    if(test1()) {
        cout << "TEST 2 PASSED!" << endl;
    }else {
        cout << "TEST 2 FAILED!" << endl;
    }
    if(test2()) {
        cout << "TEST 3 PASSED!" << endl;
    }else {
        cout << "TEST 3 FAILED!" << endl;
    }
    if(test3()) {
        cout << "TEST 4 PASSED!" << endl;
    }else {
        cout << "TEST 4 FAILED!" << endl;
    }
    if(test4()) {
        cout << "TEST 5 PASSED!" << endl;
    }else {
        cout << "TEST 5 FAILED!" << endl;
    }
    if(test5()) {
        cout << "TEST 6 PASSED!" << endl;
    }else {
        cout << "TEST 6 FAILED!" << endl;
    }
    if(test6()) {
        cout << "TEST 7 PASSED!" << endl;
    }else {
        cout << "TEST 7 FAILED!" << endl;
    }
    if(test7()) {
        cout << "TEST 8 PASSED!" << endl;
    }else {
        cout << "TEST 8 FAILED!" << endl;
    }
    if(test8()) {
        cout << "TEST 9 PASSED!" << endl;
    }else {
        cout << "TEST 9 FAILED!" << endl;
    }
    if(test9()) {
        cout << "TEST 10 PASSED!" << endl;
    }else {
        cout << "TEST 10 FAILED!" << endl;
    }
    
    return 0;
}


