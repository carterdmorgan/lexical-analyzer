//
//  Query.cpp
//  LexicalAnalyzer
//
//  Created by Morgan, Carter on 10/5/18.
//  Copyright © 2018 carterdmorgan. All rights reserved.
//

#include "Query.h"
#include "Utilities.h"
#include "TokenType.h"
#include "InvalidTokenException.cpp"
#include <iostream>

Query::Query(Lex& lex) : Predicate(lex) {
    try {
        Utilities::checkFor(lex, TokenType::Q_MARK);
    }catch (InvalidTokenException e) {
        for(Parameter* param : parameters) {
            delete param;
        }
        throw e;
    }
    
}
