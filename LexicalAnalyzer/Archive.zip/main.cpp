//
//  main.cpp
//  LexicalAnalyzer
//
//  Created by Morgan, Carter on 9/20/18.
//  Copyright © 2018 carterdmorgan. All rights reserved.
//

#include <iostream>
#include <string>
#include <stdio.h>
#include <ctype.h>
#include <sstream>
#include <fstream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include "Lex.h"
#include "TokenType.h"
#include "DatalogProgram.h"
#include "TokenTools.h"
#include "Scheme.h"
#include "Fact.h"
#include "Rule.h"
#include "Query.h"
#include "DLString.h"
#include "Header.h"
#include "Table.h"
#include "NonUnionCompatibleException.cpp"

using namespace std;

int returnRelationsIndex(vector<Table>& relations, string id) {
    int index = -1;
    
    for(int i = 0; i < (int) relations.size(); i++) {
        if(relations.at(i).name == id) {
            index = i;
            break;
        }
    }
    
    return index;
}

void prepareHeader(DatalogProgram& datalogProgram, Table& table, int k) {
    for(int i = 0; i < (int) datalogProgram.schemes.listOfSchemes.at(k).ids.size(); i++) {
        table.header.push_back(datalogProgram.schemes.listOfSchemes.at(k).ids.at(i).toString());
    }
}

void prepareFacts(DatalogProgram& datalogProgram, Table& table, int k) {
    for(int i = 0; i < (int) datalogProgram.facts.factList.size(); i++) {
        if(datalogProgram.facts.factList.at(i).id.toString() == datalogProgram.schemes.listOfSchemes.at(k).id.toString()) {
            table.addFact(datalogProgram.facts.factList.at(i));
        }
    }
}

void processQueries(DatalogProgram& datalogProgram) {
    vector<Table> relations;
    
    for(int k = 0; k < (int) datalogProgram.schemes.listOfSchemes.size(); k++) {
        Table table = Table(datalogProgram.schemes.listOfSchemes.at(k).id.toString());
        prepareHeader(datalogProgram, table, k);
        prepareFacts(datalogProgram, table, k);
        relations.push_back(table);
    }
    
    for(int j = 0; j < (int) datalogProgram.queries.queriesList.size(); j++) {
        Query query = datalogProgram.queries.queriesList.at(j);
        int index = returnRelationsIndex(relations, query.id.toString());
        
        Table newTable = relations.at(index);
        
        map<string, int> ids;
        vector<int> projections;
        vector<int> columns;
        vector<string> names;
        
        for(int i = 0; i < (int) query.parameters.size(); i++) {
            if(TokenTools::getTokenTypeValue(query.parameters.at(i)->toString()) == TokenType::ID) {
                map<string, int>::iterator it = ids.find(query.parameters.at(i)->toString());
                if(it != ids.end()) {
                    int col = it->second;
                    projections.push_back(col);
                    newTable = newTable.select(col, i);
                }else {
                    projections.push_back(i);
                    ids.insert(pair<string, int>(query.parameters.at(i)->toString(), i));
                }
            }else {
                newTable = newTable.select(i, query.parameters.at(i)->toString());
            }
        }
        
        
        for(map<string, int>::iterator it = ids.begin(); it != ids.end(); it++) {
            names.push_back(it->first);
            columns.push_back(it->second);
        }
        
        projections.erase( unique( projections.begin(), projections.end() ), projections.end() );
        
        newTable = newTable.rename(columns, names);
        newTable = newTable.project(projections);
        
        
        newTable.printQueryResult(query);
    }
}

// Tests if a new table can be produced through the union function
bool test0() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    table.header = header;
    other.header = header;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    Row row1 = Row();
    row1.values.push_back("3");
    row1.values.push_back("4");
    
    table.rows.push_back(row);
    other.rows.push_back(row1);
    
    Table desired = Table("test");
    desired.header = header;
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    Table result = table.makeUnion(other);
    
    return result == desired;
}

// Tests if a NonUnionCompatibleException will be thrown if the tables do not share the same name
bool test1() {
    Table table = Table("test");
    Table other = Table("different");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    table.header = header;
    other.header = header;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    Row row1 = Row();
    row1.values.push_back("3");
    row1.values.push_back("4");
    
    table.rows.push_back(row);
    other.rows.push_back(row1);
    
    Table desired = Table("test");
    desired.header = header;
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    try {
        Table result = table.makeUnion(other);
    }catch (NonUnionCompatibleException e) {
        return true;
    }
   
    return false;
}

// Tests if a NonUnionCompatibleException will be thrown if the tables do not have matching headers
bool test2() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    Header header1 = Header();
    header1.push_back("c");
    header1.push_back("d");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    Row row1 = Row();
    row1.values.push_back("3");
    row1.values.push_back("4");
    
    table.rows.push_back(row);
    other.rows.push_back(row1);
    
    Table desired = Table("test");
    desired.header = header;
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    try {
        Table result = table.makeUnion(other);
    }catch (NonUnionCompatibleException e) {
        return true;
    }
    
    return false;
}

// Tests a union between a table and another empty table
bool test3() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    table.header = header;
    other.header = header;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    
    table.rows.push_back(row);
    
    Table desired = Table("test");
    desired.header = header;
    desired.rows.push_back(row);
    
    Table result = table.makeUnion(other);
    
    return result == desired;
}

// Tests a natural join between two standard tables and no common values between them
bool test4() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("#");
    Header header1 = Header();
    header1.push_back("A");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    Row row1 = Row();
    row1.values.push_back("2");
    Row row2 = Row();
    row2.values.push_back("a");
    Row row3 = Row();
    row3.values.push_back("b");
    Row row4 = Row();
    row4.values.push_back("c");
    
    table.rows.push_back(row);
    table.rows.push_back(row1);
    other.rows.push_back(row2);
    other.rows.push_back(row3);
    other.rows.push_back(row4);

    Table desired = Table("test");
    desired.header.push_back("#");
    desired.header.push_back("A");
    desired.rows.push_back(row.merge(row2));
    desired.rows.push_back(row.merge(row3));
    desired.rows.push_back(row.merge(row4));
    desired.rows.push_back(row1.merge(row2));
    desired.rows.push_back(row1.merge(row3));
    desired.rows.push_back(row1.merge(row4));
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}

// Tests a natural join when each table only has one row and no common values between them
bool test5() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("#");
    Header header1 = Header();
    header1.push_back("A");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    Row row2 = Row();
    row2.values.push_back("a");
    
    table.rows.push_back(row);
    other.rows.push_back(row2);
    
    Table desired = Table("test");
    desired.header.push_back("#");
    desired.header.push_back("A");
    desired.rows.push_back(row.merge(row2));
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}

// Tests a natural join with a whole bunch of input and no common values between them
bool test6() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("#");
    Header header1 = Header();
    header1.push_back("A");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    Row row1 = Row();
    row1.values.push_back("2");
    Row row2 = Row();
    row2.values.push_back("3");
    Row row3 = Row();
    row3.values.push_back("4");
    Row row4 = Row();
    row4.values.push_back("5");
    Row row5 = Row();
    row5.values.push_back("a");
    Row row6 = Row();
    row6.values.push_back("b");
    Row row7 = Row();
    row7.values.push_back("c");
    Row row8 = Row();
    row8.values.push_back("d");
    Row row9 = Row();
    row9.values.push_back("e");
    
    table.rows.push_back(row);
    table.rows.push_back(row1);
    table.rows.push_back(row2);
    table.rows.push_back(row3);
    table.rows.push_back(row4);
    other.rows.push_back(row5);
    other.rows.push_back(row6);
    other.rows.push_back(row7);
    other.rows.push_back(row8);
    other.rows.push_back(row9);
    
    Table desired = Table("test");
    desired.header.push_back("#");
    desired.header.push_back("A");
    desired.rows.push_back(row.merge(row5));
    desired.rows.push_back(row.merge(row6));
    desired.rows.push_back(row.merge(row7));
    desired.rows.push_back(row.merge(row8));
    desired.rows.push_back(row.merge(row9));
    desired.rows.push_back(row1.merge(row5));
    desired.rows.push_back(row1.merge(row6));
    desired.rows.push_back(row1.merge(row7));
    desired.rows.push_back(row1.merge(row8));
    desired.rows.push_back(row1.merge(row9));
    desired.rows.push_back(row2.merge(row5));
    desired.rows.push_back(row2.merge(row6));
    desired.rows.push_back(row2.merge(row7));
    desired.rows.push_back(row2.merge(row8));
    desired.rows.push_back(row2.merge(row9));
    desired.rows.push_back(row3.merge(row5));
    desired.rows.push_back(row3.merge(row6));
    desired.rows.push_back(row3.merge(row7));
    desired.rows.push_back(row3.merge(row8));
    desired.rows.push_back(row3.merge(row9));
    desired.rows.push_back(row4.merge(row5));
    desired.rows.push_back(row4.merge(row6));
    desired.rows.push_back(row4.merge(row7));
    desired.rows.push_back(row4.merge(row8));
    desired.rows.push_back(row4.merge(row9));
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}

// Tests a natural join when the schemas have two matching categories but in a different order, i.e. "abcd" and "cbd".
bool test7() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    header.push_back("c");
    Header header1 = Header();
    header1.push_back("c");
    header1.push_back("b");
    header1.push_back("d");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    row.values.push_back("3");
    Row row1 = Row();
    row1.values.push_back("4");
    row1.values.push_back("5");
    row1.values.push_back("6");
    Row row2 = Row();
    row2.values.push_back("3");
    row2.values.push_back("2");
    row2.values.push_back("5");
    Row row3 = Row();
    row3.values.push_back("6");
    row3.values.push_back("5");
    row3.values.push_back("8");
    Row row4 = Row();
    row4.values.push_back("3");
    row4.values.push_back("9");
    row4.values.push_back("0");
    
    table.rows.push_back(row);
    table.rows.push_back(row1);
    other.rows.push_back(row2);
    other.rows.push_back(row3);
    other.rows.push_back(row4);
    
    Table desired = Table("test");
    desired.header.push_back("a");
    desired.header.push_back("b");
    desired.header.push_back("c");
    desired.header.push_back("d");
    row.values.push_back("5");
    row1.values.push_back("8");
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}

// Tests a natural join when the schemas share only one category
bool test8() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    header.push_back("c");
    Header header1 = Header();
    header1.push_back("c");
    header1.push_back("d");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    row.values.push_back("3");
    Row row1 = Row();
    row1.values.push_back("4");
    row1.values.push_back("5");
    row1.values.push_back("6");
    Row row2 = Row();
    row2.values.push_back("3");
    row2.values.push_back("4");
    Row row3 = Row();
    row3.values.push_back("6");
    row3.values.push_back("7");
    
    table.rows.push_back(row);
    table.rows.push_back(row1);
    other.rows.push_back(row2);
    other.rows.push_back(row3);
    
    Table desired = Table("test");
    desired.header.push_back("a");
    desired.header.push_back("b");
    desired.header.push_back("c");
    desired.header.push_back("d");
    row.values.push_back("4");
    row1.values.push_back("7");
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}

// Tests a natural join with four distinct categories and two overlapping categories, i.e. "abcd" and "cdef"
bool test9() {
    Table table = Table("test");
    Table other = Table("test");
    Header header = Header();
    header.push_back("a");
    header.push_back("b");
    header.push_back("c");
    header.push_back("d");
    Header header1 = Header();
    header1.push_back("c");
    header1.push_back("d");
    header1.push_back("e");
    header1.push_back("f");
    table.header = header;
    other.header = header1;
    Row row = Row();
    row.values.push_back("1");
    row.values.push_back("2");
    row.values.push_back("3");
    row.values.push_back("4");
    Row row1 = Row();
    row1.values.push_back("4");
    row1.values.push_back("5");
    row1.values.push_back("6");
    row1.values.push_back("7");
    Row row2 = Row();
    row2.values.push_back("3");
    row2.values.push_back("4");
    row2.values.push_back("5");
    row2.values.push_back("6");
    Row row3 = Row();
    row3.values.push_back("6");
    row3.values.push_back("7");
    row3.values.push_back("8");
    row3.values.push_back("9");
    
    table.rows.push_back(row);
    table.rows.push_back(row1);
    other.rows.push_back(row2);
    other.rows.push_back(row3);
    
    Table desired = Table("test");
    desired.header.push_back("a");
    desired.header.push_back("b");
    desired.header.push_back("c");
    desired.header.push_back("d");
    desired.header.push_back("e");
    desired.header.push_back("f");
    row.values.push_back("5");
    row.values.push_back("6");
    row1.values.push_back("8");
    row1.values.push_back("9");
    desired.rows.push_back(row);
    desired.rows.push_back(row1);
    
    Table result = table.naturalJoin(other);
    
    return desired == result;
}



void runTests() {
    if(test0()) {
        cout << "Test 0 PASSED!" << endl;
    }else{
        cout << "Test 0 FAILED!" << endl;
    }
    
    if(test1()) {
        cout << "Test 1 PASSED!" << endl;
    }else{
        cout << "Test 1 FAILED!" << endl;
    }
    
    if(test2()) {
        cout << "Test 2 PASSED!" << endl;
    }else{
        cout << "Test 2 FAILED!" << endl;
    }

    if(test3()) {
        cout << "Test 3 PASSED!" << endl;
    }else{
        cout << "Test 3 FAILED!" << endl;
    }

    if(test4()) {
        cout << "Test 4 PASSED!" << endl;
    }else{
        cout << "Test 4 FAILED!" << endl;
    }

    if(test5()) {
        cout << "Test 5 PASSED!" << endl;
    }else{
        cout << "Test 5 FAILED!" << endl;
    }

    if(test6()) {
        cout << "Test 6 PASSED!" << endl;
    }else{
        cout << "Test 6 FAILED!" << endl;
    }

    if(test7()) {
        cout << "Test 7 PASSED!" << endl;
    }else{
        cout << "Test 7 FAILED!" << endl;
    }

    if(test8()) {
        cout << "Test 8 PASSED!" << endl;
    }else{
        cout << "Test 8 FAILED!" << endl;
    }

    if(test9()) {
        cout << "Test 9 PASSED!" << endl;
    }else{
        cout << "Test 9 FAILED!" << endl;
    }
}

int main(int argc, const char * argv[]) {    
//    // Part 2
//    string fileName = argv[1];
//    ifstream inFile(fileName);
//    string input = "";
//    string line;
//
//    if (inFile.is_open()) {
//        while (getline(inFile,line)) {
//            input += line;
//            input += '\n';
//        }
//        inFile.close();
//    }
//
//    DatalogProgram datalogProgram = DatalogProgram();
//
//    try {
//        Lex lex = Lex(input);
//        datalogProgram.process(lex);
//    }catch (InvalidTokenException e) {
//        cout << "Failure!" << endl;
//        cout << "  (" << e.getTokenType() << ",\"" << e.getToken() << "\"," << e.getLine() << ")" << endl;
//    }
//
//    processQueries(datalogProgram);
    
    runTests();
    
    return 0;
}


