//
//  main.cpp
//  LexicalAnalyzer
//
//  Created by Morgan, Carter on 9/20/18.
//  Copyright © 2018 carterdmorgan. All rights reserved.
//

#include <iostream>
#include <string>
#include <stdio.h>
#include <ctype.h>
#include <sstream>
#include <fstream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include "Lex.h"
#include "TokenType.h"
#include "DatalogProgram.h"
#include "TokenTools.h"
#include "Scheme.h"
#include "Fact.h"
#include "Rule.h"
#include "Query.h"
#include "DLString.h"
#include "Header.h"
#include "Table.h"
#include "NonUnionCompatibleException.cpp"
#include "Graph.h"

using namespace std;

// Three strongly connected components in a circuit
bool test0() {
    Graph graph = Graph(3);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector0.push_back(0);
    vector0.push_back(2);
    vector0.push_back(1);
    desired.push_back(vector0);
    
    return desired == result;
}

// No strongly connected components in a circuit
bool test1() {
    Graph graph = Graph(2);
    graph.addEdge(0, 1);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector<int> vector1;
    vector0.push_back(0);
    vector1.push_back(1);
    desired.push_back(vector0);
    desired.push_back(vector1);
    
    return desired == result;
}

// Three strongly connected components in a circuit and one by itself
bool test2() {
    Graph graph = Graph(4);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(0, 3);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector<int> vector1;
    vector0.push_back(0);
    vector0.push_back(2);
    vector0.push_back(1);
    desired.push_back(vector0);
    vector1.push_back(3);
    desired.push_back(vector1);
    
    return desired == result;
}

// Invert the graph
bool test3() {
    Graph graph = Graph(2);
    graph.addEdge(0, 1);
    graph = graph.getReverse();
    vector<int> result = graph.getTopologicalSort();
    vector<int> desired;
    desired.push_back(1);
    desired.push_back(0);
    
    return desired == result;
}

// Topological sort with three components
bool test4() {
    Graph graph = Graph(3);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    vector<int> result = graph.getTopologicalSort();
    vector<int> desired;
    desired.push_back(0);
    desired.push_back(1);
    desired.push_back(2);
    
    return desired == result;
}

// Topological sort with three components in a circuit
bool test5() {
    Graph graph = Graph(3);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    vector<int> result = graph.getTopologicalSort();
    vector<int> desired;
    desired.push_back(0);
    desired.push_back(1);
    desired.push_back(2);
    
    return desired == result;
}

// Topological sort with large graph
bool test6() {
    Graph graph = Graph(8);
    graph.addEdge(5, 2);
    graph.addEdge(2, 3);
    graph.addEdge(3, 1);
    graph.addEdge(5, 0);
    graph.addEdge(4, 0);
    graph.addEdge(5, 6);
    graph.addEdge(6, 7);
    vector<int> result = graph.getTopologicalSort();
    vector<int> desired;
    
    //    for(int i : result) {
    //        cout << i << " ";
    //    }
    //    cout << endl;
    
    desired.push_back(5);
    desired.push_back(6);
    desired.push_back(7);
    desired.push_back(4);
    desired.push_back(2);
    desired.push_back(3);
    desired.push_back(1);
    desired.push_back(0);
    
    return result == desired;
}

// Two sets of strongly connected components
bool test7() {
    Graph graph = Graph(6);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(2, 3);
    graph.addEdge(3, 5);
    graph.addEdge(5, 4);
    graph.addEdge(4, 3);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector<int> vector1;
    vector0.push_back(0);
    vector0.push_back(2);
    vector0.push_back(1);
    vector1.push_back(3);
    vector1.push_back(4);
    vector1.push_back(5);
    desired.push_back(vector0);
    desired.push_back(vector1);
    
    //    for(vector<int> vector : result) {
    //        for(int i : vector) {
    //            cout << i << " ";
    //        }
    //        cout << endl;
    //    }
    
    
    return result == desired;
}

// Three sets of strongly connected components
bool test8() {
    Graph graph = Graph(9);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(2, 3);
    graph.addEdge(3, 5);
    graph.addEdge(5, 4);
    graph.addEdge(4, 3);
    graph.addEdge(5, 6);
    graph.addEdge(6, 7);
    graph.addEdge(7, 8);
    graph.addEdge(8, 6);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector<int> vector1;
    vector<int> vector2;
    vector0.push_back(0);
    vector0.push_back(2);
    vector0.push_back(1);
    vector1.push_back(3);
    vector1.push_back(4);
    vector1.push_back(5);
    vector2.push_back(6);
    vector2.push_back(8);
    vector2.push_back(7);
    desired.push_back(vector0);
    desired.push_back(vector1);
    desired.push_back(vector2);
    
    return result == desired;
}

// Takes previous large graph and connects all components
bool test9() {
    Graph graph = Graph(9);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(2, 3);
    graph.addEdge(3, 5);
    graph.addEdge(5, 4);
    graph.addEdge(4, 3);
    graph.addEdge(5, 6);
    graph.addEdge(6, 7);
    graph.addEdge(7, 8);
    graph.addEdge(8, 6);
    graph.addEdge(8, 1);
    vector<vector<int>> result = graph.getSCCs();
    vector<vector<int>> desired;
    vector<int> vector0;
    vector<int> vector1;
    vector<int> vector2;
    vector0.push_back(0);
    vector0.push_back(2);
    vector0.push_back(1);
    vector0.push_back(8);
    vector0.push_back(7);
    vector0.push_back(6);
    vector0.push_back(5);
    vector0.push_back(3);
    vector0.push_back(4);
    desired.push_back(vector0);
    
    return result == desired;
}

void runTests() {
    if(test0()) {
        cout << "TEST 0 PASSED!" << endl;
    }else {
        cout << "TEST 0 FAILED!" << endl;
    }
    if(test1()) {
        cout << "TEST 1 PASSED!" << endl;
    }else {
        cout << "TEST 1 FAILED!" << endl;
    }
    if(test2()) {
        cout << "TEST 2 PASSED!" << endl;
    }else {
        cout << "TEST 2 FAILED!" << endl;
    }
    if(test3()) {
        cout << "TEST 3 PASSED!" << endl;
    }else {
        cout << "TEST 3 FAILED!" << endl;
    }
    if(test4()) {
        cout << "TEST 4 PASSED!" << endl;
    }else {
        cout << "TEST 4 FAILED!" << endl;
    }
    if(test5()) {
        cout << "TEST 5 PASSED!" << endl;
    }else {
        cout << "TEST 5 FAILED!" << endl;
    }
    if(test6()) {
        cout << "TEST 6 PASSED!" << endl;
    }else {
        cout << "TEST 6 FAILED!" << endl;
    }
    if(test7()) {
        cout << "TEST 7 PASSED!" << endl;
    }else {
        cout << "TEST 7 FAILED!" << endl;
    }
    if(test8()) {
        cout << "TEST 8 PASSED!" << endl;
    }else {
        cout << "TEST 8 FAILED!" << endl;
    }
    if(test9()) {
        cout << "TEST 9 PASSED!" << endl;
    }else {
        cout << "TEST 9 FAILED!" << endl;
    }
}

int returnRelationsIndex(vector<Table>& relations, string id) {
    int index = -1;
    
    for(int i = 0; i < (int) relations.size(); i++) {
        if(relations.at(i).name == id) {
            index = i;
            break;
        }
    }
    
    return index;
}

void prepareHeader(DatalogProgram& datalogProgram, Table& table, int k) {
    for(int i = 0; i < (int) datalogProgram.schemes.listOfSchemes.at(k).ids.size(); i++) {
        table.header.push_back(datalogProgram.schemes.listOfSchemes.at(k).ids.at(i).toString());
    }
}

void prepareFacts(DatalogProgram& datalogProgram, Table& table, int k) {
    for(int i = 0; i < (int) datalogProgram.facts.factList.size(); i++) {
        if(datalogProgram.facts.factList.at(i).id.toString() == datalogProgram.schemes.listOfSchemes.at(k).id.toString()) {
            table.addFact(datalogProgram.facts.factList.at(i));
        }
    }
}

void processQueries(DatalogProgram& datalogProgram, vector<Table>& relations) {
    for(int j = 0; j < (int) datalogProgram.queries.queriesList.size(); j++) {
        Query query = datalogProgram.queries.queriesList.at(j);
        int index = returnRelationsIndex(relations, query.id.toString());
        
        Table newTable = relations.at(index);
        
        map<string, int> ids;
        vector<int> projections;
        vector<int> columns;
        vector<string> names;
        for(int i = 0; i < (int) query.parameters.size(); i++) {
            if(TokenTools::getTokenTypeValue(query.parameters.at(i)->toString()) == TokenType::ID) {
                map<string, int>::iterator it = ids.find(query.parameters.at(i)->toString());
                if(it != ids.end()) {
                    int col = it->second;
                    projections.push_back(col);
                    newTable = newTable.select(col, i);
                }else {
                    projections.push_back(i);
                    ids.insert(pair<string, int>(query.parameters.at(i)->toString(), i));
                }
            }else {
                newTable = newTable.select(i, query.parameters.at(i)->toString());
            }
        }
        
        for(map<string, int>::iterator it = ids.begin(); it != ids.end(); it++) {
            names.push_back(it->first);
            columns.push_back(it->second);
        }
        projections.erase( unique( projections.begin(), projections.end() ), projections.end() );
        newTable = newTable.rename(columns, names);
        newTable = newTable.project(projections);
        newTable.printQueryResult(query);
    }
}

bool relationsMatch(vector<Table>& oldRelations, vector<Table>& relations) {
    for(int i = 0; i < (int) relations.size(); i++) {
        if(oldRelations.at(i) != relations.at(i)) {
            return false;
        }
    }
    return true;
}

void populatePredicateTables(Rule& rule, vector<Table>& relations, vector<Table>& predicateTables) {
    for(int i = 0; i < (int) rule.predicateList.size(); i++) {
        Predicate& predicate = rule.predicateList.at(i);
        Table predTable = relations.at(returnRelationsIndex(relations, predicate.id.toString()));
        for(int j = 0; j < (int) predicate.parameters.size(); j++) {
            predTable = predTable.rename(j, predicate.parameters.at(j)->toString());
        }
        
        for(int j = 0; j < (int) predTable.header.size(); j++) {
            if(TokenTools::getTokenTypeValue(predTable.header.at(j)) == TokenType::STRING) {
                predTable = predTable.select(j, predTable.header.at(j));
            }
        }
        predicateTables.push_back(predTable);
    }
}

void joinPredicateTables(vector<Table>& predicateTables) {
    while((int) predicateTables.size() > 1) {
        Table& firstTable = predicateTables.at(0);
        Table& nextTable = predicateTables.at(1);
        firstTable = firstTable.naturalJoin(nextTable);
        predicateTables.erase(predicateTables.begin() + 1);
    }
}

void processRules(DatalogProgram& datalogProgram, vector<Table>& relations) {
    set<string> idVertices;
    for(Rule rule : datalogProgram.rules.rulesList) {
        idVertices.insert(rule.headPredicate.id.toString());
        for(Predicate predicate : rule.predicateList) {
            idVertices.insert(predicate.id.toString());
        }
    }
    int index = 0;
    map<string, int> vertexMap;
    map<int, string> indexMap;
    Graph graph = Graph((int) idVertices.size());
    for(string vertex : idVertices) {
        vertexMap.insert(pair<string, int>(vertex, index));
        indexMap.insert(pair<int, string>(index, vertex));
        index++;
    }
    for(Rule rule : datalogProgram.rules.rulesList) {
        for(Predicate predicate : rule.predicateList) {
            int vertex1 = vertexMap.at(rule.headPredicate.id.toString());
            int vertex2 = vertexMap.at(predicate.id.toString());
            graph.addEdge(vertex1, vertex2);
        }
    }
    
    set<int> verticesToConsider;
    for(Query query : datalogProgram.queries.queriesList) {
        if(vertexMap.find(query.id.toString()) != vertexMap.end()) {
            int vertex = vertexMap.at(query.id.toString());
            // Create a list of vertices that are reachable from a given vertex
            vector<int> dfs;
            bool *visited = new bool[graph.numberOfVertices];
            for(int i = 0; i < graph.numberOfVertices; i++) {
                visited[i] = false;
            }
            dfs = graph.DFSUtil(vertex, visited, dfs);
            delete[] visited;
            copy(dfs.begin(),dfs.end(),inserter(verticesToConsider, verticesToConsider.end()));
        }
    }
    
    vector<vector<int>> sccs = graph.getSCCs();
    for(int i = (int) sccs.size() - 1; i >= 0; i--) {
        for(int j : sccs.at(i)) {
            if(verticesToConsider.find(j) == verticesToConsider.end()) {
                sccs.erase(sccs.begin() + i);
            }else {
                break;
            }
        }
    }
    
    for(vector<int> sccVector : sccs) {
        if((int) sccVector.size() > 1) {
            cout << "fixed point" << endl;
            // evaluate to a fixed point
            bool match = false;
            vector<Table> oldRelations = relations;
            vector<Rule> rules;
            
            for(int j = 0; j < (int) sccVector.size(); j++) {
                int index = sccVector.at(j);
                string id = indexMap.at(index);
                int ruleIndex = -1;
                
                for(int i = 0; i < (int) datalogProgram.rules.rulesList.size(); i++) {
                    if(datalogProgram.rules.rulesList.at(i).headPredicate.id.toString() == id) {
                        ruleIndex = i;
                        break;
                    }
                }
                
                if(ruleIndex > -1) {
                    rules.push_back(datalogProgram.rules.rulesList.at(ruleIndex));
                }
            }
            
            
            while(!match) {
                cout << "FIXED POINT RULES:" << endl;
                for(Rule rule : rules) {
                    cout << rule.headPredicate.id.toString() << endl;
                    vector<Table> predicateTables;
                    
                    Table& table = relations.at(returnRelationsIndex(relations, rule.headPredicate.id.toString()));
                    
                    populatePredicateTables(rule, relations, predicateTables);
                    
                    joinPredicateTables(predicateTables);
                    
                    vector<string> names;
                    
                    for(Id id : rule.headPredicate.ids) {
                        names.push_back(id.toString());
                    }
                    
                    Table& completePredTable = predicateTables.at(0);
                    
                    completePredTable = completePredTable.project(names);
                    
                    Header temp = table.header;
                    table.header.clear();
                    
                    for(string name : names) {
                        table.header.push_back(name);
                    }
                    
                    table = table.makeUnion(completePredTable);
                    
                    table.header = temp;
                }
                
                match = relationsMatch(oldRelations, relations);
                
                oldRelations = relations;
            }
        }else {
            cout << "single" << endl;
            int index = sccVector.at(0);
            string id = indexMap.at(index);
            int ruleIndex = -1;
            
            for(int i = 0; i < (int) datalogProgram.rules.rulesList.size(); i++) {
                if(datalogProgram.rules.rulesList.at(i).headPredicate.id.toString() == id) {
                    ruleIndex = i;
                    break;
                }
            }
            
            if(ruleIndex > -1) {
                cout << "evaluating single rule" << endl;
                
                Rule& rule = datalogProgram.rules.rulesList.at(ruleIndex);
                
                bool recursive = false;
                
                for(Predicate predicate : rule.predicateList) {
                    if(rule.headPredicate.id.toString() == predicate.id.toString()) {
                        recursive = true;
                        break;
                    }
                }
                
                if(recursive) {
                    bool match = false;
                    vector<Table> oldRelations = relations;
                    while(!match) {
                        cout << "RECURSIVE RULE" << endl;
                        cout << rule.headPredicate.id.toString() << endl;
                        vector<Table> predicateTables;
                        
                        Table& table = relations.at(returnRelationsIndex(relations, rule.headPredicate.id.toString()));
                        
                        populatePredicateTables(rule, relations, predicateTables);
                        
                        joinPredicateTables(predicateTables);
                        
                        vector<string> names;
                        
                        for(Id id : rule.headPredicate.ids) {
                            names.push_back(id.toString());
                        }
                        
                        Table& completePredTable = predicateTables.at(0);
                        
                        completePredTable = completePredTable.project(names);
                        
                        Header temp = table.header;
                        table.header.clear();
                        
                        for(string name : names) {
                            table.header.push_back(name);
                        }
                        
                        table = table.makeUnion(completePredTable);
                        
                        table.header = temp;
                        
                        match = relationsMatch(oldRelations, relations);
                        
                        oldRelations = relations;
                    }
                }else {
                    vector<Table> predicateTables;
                    
                    Table& table = relations.at(returnRelationsIndex(relations, rule.headPredicate.id.toString()));
                    
                    populatePredicateTables(rule, relations, predicateTables);
                    
                    joinPredicateTables(predicateTables);
                    
                    vector<string> names;
                    
                    for(Id id : rule.headPredicate.ids) {
                        names.push_back(id.toString());
                    }
                    
                    Table& completePredTable = predicateTables.at(0);
                    
                    completePredTable = completePredTable.project(names);
                    
                    Header temp = table.header;
                    table.header.clear();
                    
                    for(string name : names) {
                        table.header.push_back(name);
                    }
                    
                    table = table.makeUnion(completePredTable);
                    
                    table.header = temp;
                }
            }
        }
    }
    delete[] graph.adj;
}

int main(int argc, const char * argv[]) {
    string fileName = argv[1];
    ifstream inFile(fileName);
    string input = "";
    string line;

    if (inFile.is_open()) {
        while (getline(inFile,line)) {
            input += line;
            input += '\n';
        }
        inFile.close();
    }

    DatalogProgram datalogProgram = DatalogProgram();

    try {
        Lex lex = Lex(input);
        datalogProgram.process(lex);
    }catch (InvalidTokenException e) {
        cout << "Failure!" << endl;
        cout << "  (" << e.getTokenType() << ",\"" << e.getToken() << "\"," << e.getLine() << ")" << endl;
    }

    vector<Table> relations;

    for(int k = 0; k < (int) datalogProgram.schemes.listOfSchemes.size(); k++) {
        Table table = Table(datalogProgram.schemes.listOfSchemes.at(k).id.toString());
        prepareHeader(datalogProgram, table, k);
        prepareFacts(datalogProgram, table, k);
        relations.push_back(table);
    }

    processRules(datalogProgram, relations); // This will change
    
    processQueries(datalogProgram, relations);
    
    return 0;
}


