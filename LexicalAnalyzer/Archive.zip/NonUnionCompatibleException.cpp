//
//  NonUnionCompatibleException.cpp
//  LexicalAnalyzer
//
//  Created by Morgan, Carter on 11/24/18.
//  Copyright © 2018 carterdmorgan. All rights reserved.
//

#include <exception>
#include <string>

using namespace std;

struct NonUnionCompatibleException : public exception {

};
